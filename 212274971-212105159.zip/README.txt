# README - Mini-Project Running Instructions
# main.py file contains all the necessary code and implementations needed for the project

#ACTIVATE the env then run:

1) Run the full experiment on MNIST:	python main.py
# The default run will store the output in the "results" folder and will run the experiment on MNIST dataset


2) Run on different dataset:	python main.py --dataset cifar10

3) Custom output folder:	python main.py --output my_results


NOTE: if needed you can also run the jupyter notebooks called CIFAR10 and MNIST to see the results in an organized way or to change the parameters